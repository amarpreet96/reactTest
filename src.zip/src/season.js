import React from 'react';

const Season = () =>{
        return <div>Hello Season</div>;
};

export default Season;